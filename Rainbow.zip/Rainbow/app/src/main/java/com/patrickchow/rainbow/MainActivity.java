package com.patrickchow.rainbow;

import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout    backgroundLayout;
    Button              red, orange, yellow, green, blue, indigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        backgroundLayout = findViewById(R.id.ConstraintID);

        //Sets background color to red
        red = findViewById(R.id.redBtn);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
            }
        });

        //Sets background color to orange
        orange = findViewById(R.id.orangeBtn);
        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_dark));
            }
        });

        //Sets background color to yellow
        yellow = findViewById(R.id.yellowBtn);
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorYellow));
            }
        });

        //Sets background color to green
        green = findViewById(R.id.greenBtn);
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
            }
        });

        //Sets background color to blue
        blue = findViewById(R.id.blueBtn);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));
            }
        });

        //Sets background color to indigo
        indigo = findViewById(R.id.indigoBtn);
        indigo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorIndigo));
            }
        });
    }
}
